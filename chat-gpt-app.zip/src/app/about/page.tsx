export default function AboutRoute() {
  return (
    <main>
      <h1 className="text-4xl font-bold">About Us</h1>
      <div className="mt-5">About Us and Our Awesome Application</div>
    </main>
  );
}